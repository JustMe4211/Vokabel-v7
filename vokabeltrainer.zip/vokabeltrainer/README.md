# VokabelTrainer

Eine responsive Progressive-Web-App für GitHub Pages. Sie kann mehrere Fotos oder Screenshots einer Vokabelliste einlesen, die Tabelle per Tesseract.js erkennen lassen, die Ergebnisse bearbeiten und anschließend Deutsch → Englisch abfragen.

## Veröffentlichung auf GitHub Pages

1. Auf GitHub ein Repository anlegen, zum Beispiel `vokabeltrainer`.
2. Alle Dateien aus diesem Ordner in das Repository hochladen.
3. Im Repository **Settings → Pages** öffnen.
4. Unter **Build and deployment** die Option **Deploy from a branch** wählen.
5. Den Branch `main` und den Ordner `/ (root)` speichern.
6. Nach dem Deployment die angezeigte GitHub-Pages-Adresse öffnen.

## Nutzung

- Fotos per Dateiauswahl oder Drag-and-drop hinzufügen.
- **Mit OCR auslesen** starten.
- Die erkannten Deutsch-/Englisch-Paare im zweiten Schritt prüfen und korrigieren.
- **Abfrage starten** wählen.
- Mit **Enter** kann eine Antwort geprüft werden.

## Hinweise

- Das erwartete Buchformat ist **Englisch links / Deutsch rechts**.
- Tesseract.js wird über ein CDN geladen. Für den ersten OCR-Lauf ist deshalb eine Internetverbindung notwendig.
- Die Bilder werden direkt im Browser verarbeitet und nicht an einen eigenen Server gesendet.
- Die fertige App kann in Safari über **Teilen → Zum Home-Bildschirm** als App auf dem iPad installiert werden.
